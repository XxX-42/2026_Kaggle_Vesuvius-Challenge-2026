# Vesuvius Challenge 2026 Source Package
"""
src: Source code for Vesuvius Challenge 2026.

Packages:
    - rgt: Relative Geological Time computation infrastructure
"""
